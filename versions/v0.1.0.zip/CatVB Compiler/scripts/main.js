import * as examples from './examples.js';

console.log("Loaded main.js")

const button = document.getElementById('codesubmit');
function compile() {
				const text = document.getElementById("message").value;
				const lines = text.split(/\r?\n/);
				let scripts = [];
				let actions = [];
				let currentEvent = null;
				let linenum = 1
				let currentFunction = null;
				for (const line of lines) {
								const trimmed = line.trim();
								const sline = trimmed.split(" ")
								const funct = sline[0].replace(/\s/g, "");
								
								if (trimmed.endsWith(":") && trimmed.startsWith("when")) {
												currentEvent = trimmed.slice(5, -1).trim();
												linenum++
												continue;
								} else if (trimmed.endsWith(":") && trimmed.startsWith("function")) {
												currentFunction = trimmed.slice(8, -1).trim();
												linenum++
												continue;
								}
								
								if (trimmed === "end") {
												if (currentEvent) {
																scripts.push(examples.returnEventobj(currentEvent, actions))
																currentEvent = null;
												} else if (currentFunction) {
																scripts.push(examples.returnFunctionobj(currentFunction, actions, []))
																currentFunction = null;
												}
												actions = []
												// Compile this line into the current function
												linenum++
												continue;
								}
								
								if (funct == "log") {
												const ret = examples.retObj(0,[sline[1]])
												actions.push(ret)
												if (sline[2]) {throw new Error(`Syntax Error: unexpected token "${sline[2]}" at line ${linenum}`)}
								} else if (funct == "set") {
												if (sline[2] !== "=") {throw new Error(`Syntax Error: unexpected token "${sline[2]}" at line ${linenum}`)}
												const ret = examples.retObj(11,[sline[1], sline[3]])
												actions.push(ret)
												if (sline[4]) {throw new Error(`Syntax Error: unexpected token "${sline[4]}" at line ${linenum}`)}
								} else if (funct != "") {
												throw new Error("Syntax Error: unknown token at line " + linenum)
								}
								linenum++
				}
				if (currentEvent) {
								throw new Error("Syntax Error: forgot to close { at line " + linenum)
				}
				const result = examples.returnScriptobj(scripts);
				return JSON.stringify(result);
};

function safecompile() {
				document.getElementById("console").value = ""
				document.getElementById("output").value = ""
				try {
  // Code that might throw an error
								document.getElementById("output").value = compile();
								document.getElementById("console").value = "Transpiled succesfully"
				} catch (error) {
  		// Code to execute if an error occurs, use console.error so execution does not stop
								document.getElementById("console").value = "An error occurred:\n\n" + error.message;
				}

};

button.onclick = safecompile

